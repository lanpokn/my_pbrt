#include"pbrt.hpp"

int main(){
    //此处前者为可输出mat版本的pbrt的路径，请根据情况自行配置
    //后续参数和命令行完全相同
    // RunPbrt("/home/lanpokn/Documents/2022/xiaomi/pbrt-v4-omni/build/pbrt /home/lanpokn/Documents/2022/xiaomi/pbrt-v4/发给海前/main/文件/mcc/mcc.pbrt");
    RunPbrt("/home/lanpokn/Documents/2022/xiaomi/pbrt-v4-omni/build/pbrt /home/lanpokn/Documents/2022/xiaomi/pbrt-v4/发给海前/main/文件/mcc/mcc.pbrt");
    // Exr2Scene("/home/lanpokn/Documents/2022/xiaomi/pbrt-v4/explosion.exr","/home/lanpokn/Documents/2022/xiaomi/pbrt-v4/scene/explosion/explosion.pbrt");
}