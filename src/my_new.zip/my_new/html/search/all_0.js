var searchData=
[
  ['basicconfig_0',['BasicConfig',['../structBasicConfig.html',1,'']]]
];
