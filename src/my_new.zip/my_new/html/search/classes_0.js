var searchData=
[
  ['basicconfig_12',['BasicConfig',['../structBasicConfig.html',1,'']]]
];
